/* Define if you have and want to use libcrypt */
#define HAVE_LIBCRYPT 0

/* Define if your Apache has src/include/compat.h */
#define HAVE_OLD_COMPAT_H 0  

/* Define if your Apache has src/include/ap_compat.h */
#define HAVE_AP_COMPAT_H 0

/* crypt capability checks */
#undef STD_DES_CRYPT
#undef EXT_DES_CRYPT
#undef MD5_CRYPT
#undef BLOWFISH_CRYPT