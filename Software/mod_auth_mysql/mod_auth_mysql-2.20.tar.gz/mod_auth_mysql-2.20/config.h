/* config.h.  Generated automatically by configure.  */
/* config.h.in.  Generated automatically from configure.in by autoheader.  */

/* Define if your C compiler doesn't accept -c and -o together.  */
/* #undef NO_MINUS_C_MINUS_O */

/* Define if you have and want to use libcrypt */
#define HAVE_LIBCRYPT 0

/* Define if your Apache has src/include/compat.h */
#define HAVE_OLD_COMPAT_H 0  

/* Define if your Apache has src/include/ap_compat.h */
#define HAVE_AP_COMPAT_H 0

/* crypt capability checks */
#define STD_DES_CRYPT 1
#define EXT_DES_CRYPT 0
#define MD5_CRYPT 0
#define BLOWFISH_CRYPT 0

/* Define if you have the crypt function.  */
#define HAVE_CRYPT 1

/* Define if you have the <crypt.h> header file.  */
/* #undef HAVE_CRYPT_H */
