Using PDFlib on EBCDIC platforms
================================

Important note: the Aladdin license does not apply to PDFlib on
EBCDIC platforms. This means you will have to purchase a commercial
PDFlib license in order to use PDFlib on AS/400, S/390, or other
EBCDIC-based platforms. PDFlib source code for EBCDIC architectures
is available under a separate license.

Note that although the PDFlib core library C code is fully EBCDIC-aware,
not all language bindings have been modified for use on EBCDIC-based hosts.
Currently only the C, C++, RPG, and Java language can be used on
EBCDIC platforms.

Pre-built PDFlib libraries for IBM eServer iSeries 400 and zSeries 390
are available from our Web site. These binaries have been built with
the IBM compiler. Note that the PDFlib DLL on MVS will not work
with programs built with the SAS C compiler since the IBM and SAS
compiler do not produce binary-compatible output. However, PDFlib
can be built with the SAS C compiler.

Please observe the notes in the PDFlib manual regarding expected
file formats (EBCDIC text vs. binary) for several items related to
PDFlib usage. These rules must strictly be observed in order to
successfully use PDFlib on EBCDIC-based platforms.

How to use the precompiled PDFlib DLL on MVS
============================================

- place PDFLIB in your MVS load library
- place PDFLIBSD in your MVS sidedeck (FB 80)

NOTE:  Upload them in 'binary' format.

See CHELLO.JCL & RUNIT.JCL for sample JCL to compile/link/run 
the standard PDFlib "Hello, World!" sample application.


Sample dataset names/layout:

 hlq.PDF.C.LIST   
 hlq.PDF.C.SRC    
 hlq.PDF.CNTL     
 hlq.PDF.H.SRC    
 hlq.PDF.LOAD     
 hlq.PDF.OBJ      
 hlq.PDF.SIDEDECK 
