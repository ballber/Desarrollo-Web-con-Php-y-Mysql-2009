Building PDFlib with MS Visual C++
==================================

To compile PDFlib with MS Visual C++, open the supplied workspace
file PDFlib.dsw which contains several projects for the core library, test
programs, and language bindings. Build the "pdflib" project, and the
"test" project.

If you want to build a Windows DLL, the PDFLIB_EXPORTS #define must be set
when building the library. This has already been done in the pdflib_dll
project.  Clients must define PDFLIB_DLL before including pdflib.h in order
to use the DLL.

There are two PDFlib projects: "pdflib" builds a static library (pdflib.lib),
and "pdflib_dll" builds a dynamic library (pdflib.dll). If you experiment
with both the static and the DLL version of PDFlib, make sure to delete
all object files ("Build, "Clean") before switching to the other kind of
library since we do not attempt to keep the objects files separately.


Building PDFlib with Borland C++ Builder
========================================

Project files for Borland C++ Builder 5 are supplied with the PDFlib
distribution.  After launching the IDE with the supplied project group
file PDFlib.bpg create the directory pdflib/Release (for the static
library project, PDFlib.lib), or pdflib/Release_DLL (for the DLL project,
PDFlib.dll). (If you know how to have the Borland IDE create these
directories automatically please let us know!).

In order to use our precompiled PDFlib DLL (which has been created with
the Microsoft Compiler) with the Borland Compiler you must convert the
import library to the Borland format with the coff2omf tool.


Building PDFlib with Metrowerks CodeWarrior
===========================================

The PDFlib distribution contains a project file for CodeWarrior 6/7 which
can be used on both Mac and Windows. The project file contains targets
for building static and DLL versions of PDFlib, as well as the pdftest
client which uses the static PDFlib library.


Building PDFlib with other Windows compilers
============================================

In order to build PDFlib with other compilers, observe the above
notes and make sure to define the preprocessor symbol WIN32.


Compiling the language wrappers
===============================

In order to compile the C wrappers for the supported languages you
will have to install the relevant source code package 
and adjust the include paths for these packages in the project files.
Since we supply prebuilt binaries for all supported languages this is
generally not required. Project files for the language wrappers are
only supplied for Microsoft Visual C++, but not any other compiler.
