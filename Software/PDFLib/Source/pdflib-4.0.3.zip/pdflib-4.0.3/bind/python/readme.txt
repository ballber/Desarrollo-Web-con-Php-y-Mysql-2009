Notes on the PDFlib Python binding:

Python 2.0 compatibility
========================

Python 2.0 is _not_ binary compatible to older versions with respect
to extensions. For this reason the same PDFlib extension can _not_
be used with Pyton 2.0 and older releases. The python1.6 directory
of the PDFlib binary distribution for Windows contains a PDFlib DLL
for Python versions older than 2.0.

By default, the MSVC project file builds a Python 2.0 compatible
extension. The "oldpython" configuration can be used to compile
PDFlib for Python versions older than 2.0.
