/*
 * modified by PDFlib GmbH
 */
 
/* $Id: port.h,v 1.13.2.4 2002/01/26 18:34:32 tm Exp $ */

#ifndef _PORT_
#define _PORT_ 1

/*
 * Setup basic type definitions and function declaratations.
 */

#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/* PDFlib GmbH: identify Mac compilers */
#if (defined macintosh || defined __POWERPC__ || \
		defined __CFM68K__ || defined __MC68K__) && !defined MAC
#define MAC
#endif

#if !defined(_WIN32_WCE)
#if defined(WIN32) || defined(OS2)
#include <fcntl.h> 
#include <sys/types.h>
#else
#include <fcntl.h> 	/* TODO: fix me */
#endif
#endif /* _WIN32_CE */

#if !defined(WIN32) && !defined(OS2) && !defined(MAC)
#include <unistd.h>
#endif

/* TODO: delete
#if defined(__PPCC__) || defined(__SC__) || defined(__MRC__)
#include <types.h>
#elif !defined(__MWERKS__) && !defined(THINK_C) && \
	!defined(__acornriscos) && !defined(applec)
#include <sys/types.h>
#endif
*/

/*
 * This maze of checks controls defines or not the
 * target system has BSD-style typdedefs declared in
 * an include file and/or whether or not to include
 * <unistd.h> to get the SEEK_* definitions.  Some
 * additional includes are also done to pull in the
 * appropriate definitions we're looking for.
 */
#if defined(__MWERKS__) || defined(THINK_C) || defined(__PPCC__) || \
		defined(__SC__) || defined(__MRC__)
#define	BSDTYPES
#define	HAVE_UNISTD_H	0

#elif (defined(_WINDOWS) || defined(__WIN32__) || defined(_Windows) \
		|| defined(_WIN32)) && !defined(unix)

#define	BSDTYPES

#elif defined(OS2_16) || defined(OS2_32)

#define	BSDTYPES
#endif

/* PDFlib GmbH: to get rid of typedef problems, we
 * prefixed these:
 */
typedef	unsigned char tif_uchar;
typedef	unsigned short tif_ushort;
typedef	unsigned int tif_uint;
typedef	unsigned long tif_ulong;

#ifndef O_RDONLY
#define O_RDONLY	0
#endif

#ifndef O_WRONLY
#define O_WRONLY	1
#endif

#ifndef O_RDWR
#define O_RDWR  	2
#endif

/*
 * dblparam_t is the type that a double precision
 * floating point value will have on the parameter
 * stack (when coerced by the compiler).
 */
typedef double dblparam_t;

#undef INLINE		/* PDFlib GmbH */
#define	INLINE	/* */

#define GLOBALDATA(TYPE,NAME)	extern TYPE NAME

#ifdef WORDS_BIGENDIAN
#undef HOST_BIGENDIAN	/* PDFlib GmbH */
#define HOST_BIGENDIAN	1
#endif

/* to allow the use of PDFlib inside of programs using the real TIFFlib */
#define TIFFGetFieldDefaulted	pdf_TIFFGetFieldDefaulted
#define TIFFVGetFieldDefaulted	pdf_TIFFVGetFieldDefaulted
#define TIFFClose	pdf_TIFFClose
#define TIFFFindCODEC	pdf_TIFFFindCODEC
#define TIFFRegisterCODEC	pdf_TIFFRegisterCODEC
#define TIFFSetCompressionScheme	pdf_TIFFSetCompressionScheme
#define TIFFUnRegisterCODEC	pdf_TIFFUnRegisterCODEC
#define _TIFFNoPreCode	pdf__TIFFNoPreCode
#define _TIFFNoRowDecode	pdf__TIFFNoRowDecode
#define _TIFFNoRowEncode	pdf__TIFFNoRowEncode
#define _TIFFNoSeek	pdf__TIFFNoSeek
#define _TIFFNoStripDecode	pdf__TIFFNoStripDecode
#define _TIFFNoStripEncode	pdf__TIFFNoStripEncode
#define _TIFFNoTileDecode	pdf__TIFFNoTileDecode
#define _TIFFNoTileEncode	pdf__TIFFNoTileEncode
#define _TIFFSetDefaultCompressionState	pdf__TIFFSetDefaultCompressionState
#define TIFFCreateDirectory	pdf_TIFFCreateDirectory
#define TIFFCurrentDirOffset	pdf_TIFFCurrentDirOffset
#define TIFFDefaultDirectory	pdf_TIFFDefaultDirectory
#define TIFFFreeDirectory	pdf_TIFFFreeDirectory
#define TIFFGetField	pdf_TIFFGetField
#define TIFFLastDirectory	pdf_TIFFLastDirectory
#define TIFFNumberOfDirectories	pdf_TIFFNumberOfDirectories
#define TIFFReassignTagToIgnore	pdf_TIFFReassignTagToIgnore
#define TIFFSetDirectory	pdf_TIFFSetDirectory
#define TIFFSetField	pdf_TIFFSetField
#define TIFFSetSubDirectory	pdf_TIFFSetSubDirectory
#define TIFFSetTagExtender	pdf_TIFFSetTagExtender
#define TIFFUnlinkDirectory	pdf_TIFFUnlinkDirectory
#define TIFFVGetField	pdf_TIFFVGetField
#define TIFFVSetField	pdf_TIFFVSetField
#define _TIFFsetByteArray	pdf__TIFFsetByteArray
#define _TIFFsetDoubleArray	pdf__TIFFsetDoubleArray
#define _TIFFsetFloatArray	pdf__TIFFsetFloatArray
#define _TIFFsetLongArray	pdf__TIFFsetLongArray
#define _TIFFsetNString	pdf__TIFFsetNString
#define _TIFFsetShortArray	pdf__TIFFsetShortArray
#define _TIFFsetString	pdf__TIFFsetString
#define _TIFFFieldWithTag	pdf__TIFFFieldWithTag
#define _TIFFFindFieldInfo	pdf__TIFFFindFieldInfo
#define _TIFFMergeFieldInfo	pdf__TIFFMergeFieldInfo
#define _TIFFPrintFieldInfo	pdf__TIFFPrintFieldInfo
#define _TIFFSampleToTagType	pdf__TIFFSampleToTagType
#define _TIFFSetupFieldInfo	pdf__TIFFSetupFieldInfo
#define TIFFReadDirectory	pdf_TIFFReadDirectory
#define TIFFWriteDirectory	pdf_TIFFWriteDirectory
#define TIFFInitDumpMode	pdf_TIFFInitDumpMode
#define TIFFError	pdf_TIFFError
#define TIFFSetErrorHandler	pdf_TIFFSetErrorHandler
#define TIFFInitCCITTFax3	pdf_TIFFInitCCITTFax3
#define TIFFInitCCITTFax4	pdf_TIFFInitCCITTFax4
#define TIFFInitCCITTRLE	pdf_TIFFInitCCITTRLE
#define TIFFInitCCITTRLEW	pdf_TIFFInitCCITTRLEW
#define _TIFFFax3fillruns	pdf__TIFFFax3fillruns
#define TIFFFlush	pdf_TIFFFlush
#define TIFFFlushData	pdf_TIFFFlushData
#define TIFFRGBAImageBegin	pdf_TIFFRGBAImageBegin
#define TIFFRGBAImageEnd	pdf_TIFFRGBAImageEnd
#define TIFFRGBAImageGet	pdf_TIFFRGBAImageGet
#define TIFFRGBAImageOK	pdf_TIFFRGBAImageOK
#define TIFFReadRGBAImage	pdf_TIFFReadRGBAImage
#define TIFFReadRGBAStrip	pdf_TIFFReadRGBAStrip
#define TIFFReadRGBATile	pdf_TIFFReadRGBATile
#define TIFFInitNeXT	pdf_TIFFInitNeXT
#define TIFFClientOpen	pdf_TIFFClientOpen
#define TIFFCurrentDirectory	pdf_TIFFCurrentDirectory
#define TIFFCurrentRow	pdf_TIFFCurrentRow
#define TIFFCurrentStrip	pdf_TIFFCurrentStrip
#define TIFFCurrentTile	pdf_TIFFCurrentTile
#define TIFFFileName	pdf_TIFFFileName
#define TIFFFileno	pdf_TIFFFileno
#define TIFFGetMode	pdf_TIFFGetMode
#define TIFFIsByteSwapped	pdf_TIFFIsByteSwapped
#define TIFFIsMSB2LSB	pdf_TIFFIsMSB2LSB
#define TIFFIsTiled	pdf_TIFFIsTiled
#define TIFFIsUpSampled	pdf_TIFFIsUpSampled
#define TIFFInitPackBits	pdf_TIFFInitPackBits
#define TIFFPredictorInit	pdf_TIFFPredictorInit
#define TIFFPrintDirectory	pdf_TIFFPrintDirectory
#define _TIFFprintAscii	pdf__TIFFprintAscii
#define _TIFFprintAsciiTag	pdf__TIFFprintAsciiTag
#define TIFFReadBufferSetup	pdf_TIFFReadBufferSetup
#define TIFFReadEncodedStrip	pdf_TIFFReadEncodedStrip
#define TIFFReadEncodedTile	pdf_TIFFReadEncodedTile
#define TIFFReadRawStrip	pdf_TIFFReadRawStrip
#define TIFFReadRawTile	pdf_TIFFReadRawTile
#define TIFFReadScanline	pdf_TIFFReadScanline
#define TIFFReadTile	pdf_TIFFReadTile
#define _TIFFNoPostDecode	pdf__TIFFNoPostDecode
#define _TIFFSwab16BitData	pdf__TIFFSwab16BitData
#define _TIFFSwab32BitData	pdf__TIFFSwab32BitData
#define _TIFFSwab64BitData	pdf__TIFFSwab64BitData
#define TIFFComputeStrip	pdf_TIFFComputeStrip
#define TIFFDefaultStripSize	pdf_TIFFDefaultStripSize
#define TIFFNumberOfStrips	pdf_TIFFNumberOfStrips
#define TIFFRasterScanlineSize	pdf_TIFFRasterScanlineSize
#define TIFFScanlineSize	pdf_TIFFScanlineSize
#define TIFFStripSize	pdf_TIFFStripSize
#define TIFFVStripSize	pdf_TIFFVStripSize
#define _TIFFDefaultStripSize	pdf__TIFFDefaultStripSize
#define TIFFGetBitRevTable	pdf_TIFFGetBitRevTable
#define TIFFReverseBits	pdf_TIFFReverseBits
#define TIFFSwabArrayOfDouble	pdf_TIFFSwabArrayOfDouble
#define TIFFSwabArrayOfLong	pdf_TIFFSwabArrayOfLong
#define TIFFSwabArrayOfShort	pdf_TIFFSwabArrayOfShort
#define TIFFSwabDouble	pdf_TIFFSwabDouble
#define TIFFSwabLong	pdf_TIFFSwabLong
#define TIFFSwabShort	pdf_TIFFSwabShort
#define TIFFInitThunderScan	pdf_TIFFInitThunderScan
#define TIFFCheckTile	pdf_TIFFCheckTile
#define TIFFComputeTile	pdf_TIFFComputeTile
#define TIFFDefaultTileSize	pdf_TIFFDefaultTileSize
#define TIFFNumberOfTiles	pdf_TIFFNumberOfTiles
#define TIFFTileRowSize	pdf_TIFFTileRowSize
#define TIFFTileSize	pdf_TIFFTileSize
#define TIFFVTileSize	pdf_TIFFVTileSize
#define _TIFFDefaultTileSize	pdf__TIFFDefaultTileSize
#define TIFFFdOpen	pdf_TIFFFdOpen
#define TIFFOpen	pdf_TIFFOpen
#define _TIFFfree	pdf__TIFFfree
#define _TIFFmalloc	pdf__TIFFmalloc
#define _TIFFmemcmp	pdf__TIFFmemcmp
#define _TIFFmemcpy	pdf__TIFFmemcpy
#define _TIFFmemset	pdf__TIFFmemset
#define _TIFFrealloc	pdf__TIFFrealloc
#define TIFFGetVersion	pdf_TIFFGetVersion
#define TIFFSetWarningHandler	pdf_TIFFSetWarningHandler
#define TIFFWarning	pdf_TIFFWarning
#define TIFFSetWriteOffset	pdf_TIFFSetWriteOffset

/* globals */
#define _TIFFBuiltinCODECS	pdf__TIFFBuiltinCODECS
#define _TIFFerrorHandler	pdf__TIFFerrorHandler
#define _TIFFwarningHandler	pdf__TIFFwarningHandler
#define tiffDataWidth	pdf_tiffDataWidth
#define TIFFFaxBlackCodes	pdf_TIFFFaxBlackCodes
#define TIFFFaxWhiteCodes	pdf_TIFFFaxWhiteCodes
#define TIFFFaxBlackTable	pdf_TIFFFaxBlackTable
#define TIFFFaxMainTable	pdf_TIFFFaxMainTable
#define TIFFFaxWhiteTable	pdf_TIFFFaxWhiteTable

#endif /* _PORT_ */
