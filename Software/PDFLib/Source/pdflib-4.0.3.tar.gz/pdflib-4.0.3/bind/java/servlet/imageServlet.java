/* $Id: imageServlet.java,v 1.1.2.3 2002/01/28 17:32:56 rp Exp $
 *
 * PDFlib client: image example in JavaServlet
 */

import java.io.*;
import javax.servlet.*;
import com.pdflib.pdflib;

public class imageServlet extends GenericServlet
{
    public void service (ServletRequest request, ServletResponse response) throws
	OutOfMemoryError, IOException, IllegalArgumentException,
	IndexOutOfBoundsException, ClassCastException, ArithmeticException,
	RuntimeException, InternalError, UnknownError
    {
	int image;
	float width, height;
	pdflib p;
	String imagefile = "nesrin.jpg";
	byte[] buf;
	ServletOutputStream output;
	int manual, page;

	p = new pdflib();

	p.open_file("");

	p.set_info("Creator", "imageServlet.java");
	p.set_info("Author", "Rainer Ploeckl");
	p.set_info("Title", "image sample (JavaServlet)");

	if (request.getParameter("image") != null){
	    imagefile = request.getParameter("image") ;
	}

	image = p.open_image_file("jpeg", imagefile, "", 0);

	if (image == -1) {
	    System.err.println("Couldn't open image file "+imagefile+".\n");
	    System.exit(1);
	}

	// See the PDFlib manual for more advanced image size calculations
	width = p.get_value("imagewidth", image);
	height = p.get_value("imageheight", image);

	// We generate a page with the image's dimensions
	p.begin_page(width, height);
	p.place_image(image, (float) 0.0, (float) 0.0, (float) 1.0);
	p.close_image(image);
	p.end_page();

	p.close();
        buf = p.get_buffer();

        response.setContentType("application/pdf");
        response.setContentLength(buf.length);

        output = response.getOutputStream();
        output.write(buf);
        output.close();

    }
}
