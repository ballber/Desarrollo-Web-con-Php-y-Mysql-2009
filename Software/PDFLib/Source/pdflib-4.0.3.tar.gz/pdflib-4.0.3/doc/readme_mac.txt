Building PDFlib on Mac OS 9
===========================

To compile PDFlib with Metrowerks CodeWarrior, open the supplied
project file PDFlib.mcp with the Metrowerks IDE. The project file
contains a target for building a static PDFlib library, and a
target for building the pdftest sample program which uses this
static PDFlib library. pdftest is a simple command-line application
which demonstrates the use of PDFlib, but doesn't make any attempt
at doing fancy Mac GUI stuff.

In order to build a shared PDFlib library you'll have to define
the PDFLIB_EXPORTS preprocessor symbol (preferably in a new prefix
file).


Using the C and C++ samples on Mac OS 9
=======================================

Using the supplied PDFlib-test.mcp project file for CodeWarrior you
can check your PDFlib installation. It contains individual targets
for the supplied C and C++ samples. These will silently generate
a PDF document in the test, bind:c or bind:cpp folders.

In order to make the C and C++ samples work you must change the paths to
the input files in the source code of the quickreference, personalize,
and image samples to use ':' instead of '/' as a path delimiter, e.g:

"../../doc/PDFlib-manual.pdf" ==> ":::doc:PDFlib-manual.pdf"


Compiling the language wrappers
===============================

In order to compile the C wrappers for the supported languages you
will have to install the relevant source code package, and adjust the
include paths for these packages in the project file. Be warned that
compiling the language wrappers is a delicate process due to permanent
changes to the binding environments and setup.

Since we supply prebuilt binaries this will generally not be required.

Note: Mac OS X is fully supported as a Unix platform.
